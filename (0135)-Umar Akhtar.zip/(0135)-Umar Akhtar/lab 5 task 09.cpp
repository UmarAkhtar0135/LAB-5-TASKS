// UMAR AKHTAR 
// L1F26BSCS0135
#include <iostream>
using namespace std;
int main()
{
	int units;
	cout << "Enter Units: " << endl;
	cin >> units;

	if (units <= 100)
	{
		cout << "low usage";
	}
	else if (units <= 300)
	{
		cout << "Medium";
	}
	else if (units > 300)
	{
		cout << "High";
	}

	// 75 low
	//250 medium
	// 300 medium
	// 450 high
}