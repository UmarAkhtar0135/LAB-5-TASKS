// UMAR AKHTAR
// L1F26BSCS0135

#include <iostream>
using namespace std;
int main()
{
	int temp;
	cout << "Enter Temperature: " << endl;
	cin >> temp;

	if (temp < 10)
	{
		cout << "Cold";
	}
	else if (temp < 25)
	{
		cout << "Pleasent";
	}
	else if (temp < 35)
	{
		cout << "warm";
	}
	else
		cout << "Hot";
	return 0;



	// 18 < 10 → False
  // 18 < 25 → True
  // 18 < 35 Not checked            


}