// Umar Akhtar 
// L1F26BSCS0135

#include <iostream>
using namespace std;

int main()
{
	int billAmount;
	cout << "Enter your Bill: " << endl;
	cin >> billAmount;


	if (billAmount > 5000)
	{
		cout << "You are Qualified for the disocunt";
	}
	return 0;
}