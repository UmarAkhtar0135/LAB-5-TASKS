//UMAR AKHTAR
// L1F26BSCS0135


#include <iostream>
using namespace std;

int main()
{
    int marks;

    cout << "Enter your marks: ";
    cin >> marks;

    if (marks >= 85)
    {
        cout << "Scholarship awarded";
    }
    else
    {
        cout << "Scholarship not awarded";
    }

    return 0;
}
