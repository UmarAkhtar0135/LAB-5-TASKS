// UMAR AKHTAR
// L1F26BSCS0135
#include <iostream>
using namespace std;

int main()

{
	int number;
	cout << "Enter a number: " << endl;
	cin >> number;
	if (number > 0)
	{
		cout << "Positive Number";
	}
	/*else
		cout << "Negative number";*/

	// if the number is 0 or less than 0, nothing will be printed as the task 1 said.

	return 0;
}

