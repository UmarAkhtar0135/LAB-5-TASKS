// UMAR AKHTAR
// L1F26BSCS0135
#include <iostream>
using namespace std;
int main() {
	int marks;
	cout << "Enter marks: ";
	cin >> marks;
	if (marks >= 50)   // mistake was progammer used = instead of ==
	{
		cout << "Pass" << endl;
	}
	else {
		cout << "Fail" << endl;
	}
	return 0;


	// == checks whether two values are equa
	// = gives a value to a variable
}