// UMAR AKHTAR
// L1F26BSCS0135
#include <iostream>
using namespace std;
int main()

{
	int visitorage;
	cout << "Enter your age: " << endl;
	cin >> visitorage;

	if (visitorage < 0)
	{
		cout << "Invalid age";
	}
	else if (visitorage < 5)
	{
		cout << "Free entery";
	}
	else if (visitorage <= 17)
	{
		cout << "Student ticket: Rs 200";
	}
	else if (visitorage <= 59)
	{
		cout << "Adult ticket: Rs500";

	}
	else
		cout << "Senoir ticket: Rs 300";

// Test results:
// Age -1: Invalid age
// Age 4: Free entry
// Age 12: Child/Student ticket: Rs. 200
// Age 35: Adult ticket: Rs. 500
// Age 60: Senior ticket: Rs. 300


}