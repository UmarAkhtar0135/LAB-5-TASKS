//UMAR AKHTAR 
//L1F26BSCS135

#include <iostream>
using namespace std;
int main()
{
	int Firstnumber, secondnumber;
	cout << "Enter first number: " << endl;
	cin >> Firstnumber;
	cout << "Enter second number: " << endl;
	cin >> secondnumber;



	if (Firstnumber > secondnumber)
	{
		cout << "First number is greater";
	}
	else
		cout << "first number is not greater";
	return 0;
   
	// if both number are equal, it will excute the else statement because > means greater and it strictly follows that rules
}