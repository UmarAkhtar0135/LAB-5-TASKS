// UMAR AKHTAR
// L1F26BSCS0135
#include <iostream>
using namespace std;
int main()
{
	int marks;
	cout << "Enter your Marks out of 100: " << endl;
	cin >> marks;
	if (marks < 0)
	{
		cout << "Invalid marks";
	}
	else if (marks > 100)
	{
		cout << "Invalid marks";
	}

	else if (marks >= 90)
	{
		cout << "A";
	}
	else if (marks >= 80)
	{
		cout << "B";
	}
	else if (marks >= 70)
	{
		cout << "C";
	}
	else if (marks >= 60)
	{
		cout << "D";
	}
	else
	{
		cout << "F";
		return 0;
	}






	// The highest range should be checked first because if we check lower ranges first
   // higher marks could match them and receive the wrong grade

}