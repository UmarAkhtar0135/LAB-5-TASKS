// UMAR AKHTAR
// L1F26BSCS0135
#include <iostream>
using namespace std;
int main()
{
	int x;
	cout << "enter a number: " << endl;
	cin >> x;

	if (x % 2 == 0)
	{
		cout << "Number is even";
	}
	else
		cout << "Number is odd";
	return 0;
}